from flask import Flask, jsonify
from flask_cors import CORS
import warnings
from qiskit_ibm_runtime import QiskitRuntimeService

warnings.filterwarnings("ignore", category=UserWarning)

API_KEY = "Kz14SG5DnDhXViiE3E3x5zOF9xfEyvMRbJ0Ubd806AWf"
service = QiskitRuntimeService(channel="ibm_cloud", token=API_KEY)

app = Flask(__name__)

# ✅ Allow all routes + methods + headers from React frontend
CORS(app, resources={r"/api/*": {"origins": "http://localhost:5173"}},
     supports_credentials=True)

@app.route("/api/run-bell", methods=["GET", "OPTIONS"])
def run_bell():
    try:
        # Example dummy response (replace with your Bell job runner)
        return jsonify({
            "backend": "ibmq_qasm_simulator",
            "job_id": "12345",
            "status": "COMPLETED",
            "counts": {"00": 2048, "11": 2048}
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
