from fastapi import FastAPI
from qiskit_ibm_runtime import QiskitRuntimeService

app = FastAPI()

# Initialize IBM Quantum connection
service = QiskitRuntimeService(channel="ibm_cloud")

@app.get("/jobs")
async def get_jobs():
    # Fetch jobs from IBM Quantum (limit to 5 for testing)
    jobs = service.jobs(limit=5)

    job_list = []
    for job in jobs:
        job_list.append({
            "job_id": job.job_id,
            "backend": job.backend().name,
            "status": job.status().name,
            "creation_date": str(job.creation_date)
        })

    return job_list


from qiskit_ibm_runtime import QiskitRuntimeService

QiskitRuntimeService.save_account(channel="ibm_cloud", token="Kz14SG5DnDhXViiE3E3x5zOF9xfEyvMRbJ0Ubd806AWf")