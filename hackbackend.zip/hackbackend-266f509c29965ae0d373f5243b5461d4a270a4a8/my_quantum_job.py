from qiskit import QuantumCircuit
from qiskit_ibm_runtime import QiskitRuntimeService, SamplerV2

# Connect to IBM Quantum with the saved credentials
service = QiskitRuntimeService()

# Create a simple Bell circuit
qc = QuantumCircuit(2)
qc.h(0)
qc.cx(0, 1)
qc.measure_all()

# --- Find and select a working backend ---
available_simulators = service.backends(simulator=True)

if not available_simulators:
    print("No available simulators found. Please check your account and internet connection.")
    exit()

# Pick the first simulator (usually 'simulator_stabilizer' or similar)
backend = available_simulators[0]
print(f"✅ Found and selected backend: {backend.name}")

# Use the SamplerV2 primitive to execute the circuit
sampler = SamplerV2(backend)
job = sampler.run([qc])

# Wait for job to finish and get results
result = job.result()

# Extract measurement counts
counts = result[0].data.meas.get_counts()
print("Counts:", counts)
