from flask import Flask, jsonify
from flask_cors import CORS
import sample_job  # Import the refactored mo

# Suppress Qiskit warnings for a cleaner console
warnings.filterwarnings("ignore", category=UserWarning)

# Initialize the Flask application
app = Flask(__name__)
# Enable CORS to allow React frontend[](http://localhost:3000) to connect
CORS(app, resources={r"/api/*": {"origins": "http://localhost:5173"}})

# Run Bell Circuit API Endpoint
@app.route("/api/run-bell", methods=["GET"])
def run_bell():
    try:
        # Call the function from sample_job.py
        result = sample_job.run_bell_job()
        return jsonify(result)
    except Exception as e:
        import traceback
        print(f"🔥 Error running Bell circuit: {e}")
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    print("✅ Flask server running on http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=True)